import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Locale;

public class SellerProductForm extends JDialog {
    private JPanel sellerProductPanel;
    private JTable productsTable;
    private JButton sortByNameButton;
    private JButton sortByPriceButton;
    private JButton newProductButton;
    private JButton modifyProductButton;
    private JButton deleteProductButton;

    private Store store;

    private SellerItemTableModel sellerItemTableModel;

    private ClothingMarketPlace marketPlace;

    private boolean sortByNameAscending = true;
    private boolean sortByPriceAscending = true;

    public SellerProductForm(JFrame parent, Store store, ClothingMarketPlace marketPlace) {
        super(parent);
        marketPlace.initGui(this, "Products", sellerProductPanel, 800, 500);
        this.marketPlace = marketPlace;
        this.store = store;
        this.sellerItemTableModel = new SellerItemTableModel();
        ArrayList<ShoppingItem> storeItems = marketPlace.getShoppingItems(store);
        for (ShoppingItem shoppingItem : storeItems) {
            this.sellerItemTableModel.addElement(shoppingItem);
        }
        this.productsTable.setModel(this.sellerItemTableModel);
        this.productsTable.getColumnModel().getColumn(0).setPreferredWidth(200);
        this.productsTable.getColumnModel().getColumn(1).setPreferredWidth(400);
        this.sortByNameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortByNameAction();
            }
        });
        this.sortByPriceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortByPriceAction();
            }
        });
        this.newProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                newProductAction();
            }
        });
        this.modifyProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifyProductAction();
            }
        });
        this.deleteProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteProductAction();
            }
        });
    }

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public SellerItemTableModel getSellerItemTableModel() {
        return sellerItemTableModel;
    }

    public void setSellerItemTableModel(SellerItemTableModel sellerItemTableModel) {
        this.sellerItemTableModel = sellerItemTableModel;
    }

    public ClothingMarketPlace getMarketPlace() {
        return marketPlace;
    }

    public void setMarketPlace(ClothingMarketPlace marketPlace) {
        this.marketPlace = marketPlace;
    }

    public boolean isSortByNameAscending() {
        return sortByNameAscending;
    }

    public void setSortByNameAscending(boolean sortByNameAscending) {
        this.sortByNameAscending = sortByNameAscending;
    }

    public boolean isSortByPriceAscending() {
        return sortByPriceAscending;
    }

    public void setSortByPriceAscending(boolean sortByPriceAscending) {
        this.sortByPriceAscending = sortByPriceAscending;
    }

    private void sortByNameAction() {
        marketPlace.sortByName(sellerItemTableModel.getShoppingItems(), sortByNameAscending);
        sellerItemTableModel.fireTableDataChanged();
        sortByNameAscending = !sortByNameAscending;
    }

    private void sortByPriceAction() {
        marketPlace.sortByPrice(sellerItemTableModel.getShoppingItems(), sortByPriceAscending);
        sellerItemTableModel.fireTableDataChanged();
        sortByPriceAscending = !sortByPriceAscending;
    }

    private void newProductAction() {
        JTextField nameField = new JTextField();
        JTextField descriptionField = new JTextField();
        JTextField quantityField = new JTextField();
        JTextField priceField = new JTextField();
        Object[] message = {
                "Name:", nameField,
                "Description:", descriptionField,
                "Quantity:", quantityField,
                "Price:", priceField,
        };
        int option = JOptionPane.showConfirmDialog(null, message, "New product", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            String description = descriptionField.getText();
            String quantity = quantityField.getText();
            String price = priceField.getText();
            Product product;
            try {
                product = store.createProduct(name, description, Integer.parseInt(quantity), Double.parseDouble(price));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(sellerProductPanel,
                        "Quantity or Price value is invalid. Please try again",
                        "New product failed",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (product == null) {
                JOptionPane.showMessageDialog(sellerProductPanel,
                        "Product already exists or one of field is incorrect. Please try again",
                        "New product failed",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            product.setId(marketPlace.getProductCount());
            marketPlace.tickStoreCount();
            sellerItemTableModel.addElement(new ShoppingItem(product, store.getSellerEmail(), store.getName()));
            sellerItemTableModel.fireTableDataChanged();
        }
    }

    private void modifyProductAction() {
        if (productsTable.getSelectedRowCount() != 1) {
            JOptionPane.showMessageDialog(productsTable,
                    "one product need to be selected",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        ShoppingItem shoppingItem = sellerItemTableModel.getShoppingItems().get(productsTable.getSelectedRow());

        JTextField nameField = new JTextField(shoppingItem.getProduct().getName());
        JTextField descriptionField = new JTextField(shoppingItem.getProduct().getDescription());
        JTextField quantityField = new JTextField(Integer.toString(shoppingItem.getProduct().getQuantity()));
        JTextField priceField = new JTextField(Double.toString(shoppingItem.getProduct().getPrice()));
        Object[] message = {
                "Name:", nameField,
                "Description:", descriptionField,
                "Quantity:", quantityField,
                "Price:", priceField,
        };
        int option = JOptionPane.showConfirmDialog(null, message, "Modify product", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            String description = descriptionField.getText();
            String quantity = quantityField.getText();
            String price = priceField.getText();
            Product product;
            try {
                shoppingItem.getProduct().setName(name);
                shoppingItem.getProduct().setDescription(description);
                shoppingItem.getProduct().setQuantity(Integer.parseInt(quantity));
                shoppingItem.getProduct().setPrice(Double.parseDouble(price));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(sellerProductPanel,
                        "One of the value is invalid. Please try again",
                        "Modify product failed",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            sellerItemTableModel.fireTableDataChanged();
        }
    }

    private void deleteProductAction() {
        if (productsTable.getSelectedRowCount() != 1) {
            JOptionPane.showMessageDialog(productsTable,
                    "one product need to be selected",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        ShoppingItem shoppingItem = sellerItemTableModel.getShoppingItems().get(productsTable.getSelectedRow());
        sellerItemTableModel.removeElement(shoppingItem);
        store.deleteProduct(shoppingItem.getProduct().getId());
        sellerItemTableModel.fireTableDataChanged();
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        sellerProductPanel = new JPanel();
        sellerProductPanel.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(4, 1, new Insets(5, 10, 5, 10), -1, -1));
        final JPanel panel1 = new JPanel();
        panel1.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(5, 10, 5, 10), -1, -1));
        sellerProductPanel.add(panel1, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JLabel label1 = new JLabel();
        Font label1Font = this.$$$getFont$$$("Arial Black", Font.BOLD, 12, label1.getFont());
        if (label1Font != null) label1.setFont(label1Font);
        label1.setText("Products");
        panel1.add(label1, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel2 = new JPanel();
        panel2.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(5, 10, 5, 10), -1, -1));
        sellerProductPanel.add(panel2, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final JScrollPane scrollPane1 = new JScrollPane();
        panel2.add(scrollPane1, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        productsTable = new JTable();
        scrollPane1.setViewportView(productsTable);
        final JPanel panel3 = new JPanel();
        panel3.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 3, new Insets(5, 10, 5, 10), -1, -1));
        sellerProductPanel.add(panel3, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        newProductButton = new JButton();
        newProductButton.setText("New Product");
        panel3.add(newProductButton, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 1, false));
        modifyProductButton = new JButton();
        modifyProductButton.setText("Modify Product");
        panel3.add(modifyProductButton, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        deleteProductButton = new JButton();
        deleteProductButton.setText("Delete Product");
        panel3.add(deleteProductButton, new com.intellij.uiDesigner.core.GridConstraints(0, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel4 = new JPanel();
        panel4.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(5, 10, 5, 10), -1, -1));
        sellerProductPanel.add(panel4, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        sortByNameButton = new JButton();
        sortByNameButton.setText("Sort by Name");
        panel4.add(sortByNameButton, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        sortByPriceButton = new JButton();
        sortByPriceButton.setText("Sort by Price");
        panel4.add(sortByPriceButton, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return sellerProductPanel;
    }
}
